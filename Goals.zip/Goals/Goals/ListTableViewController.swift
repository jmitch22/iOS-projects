//
//  ListTableViewController.swift
//  Goals
//
//  Created by Jada Mitchell on 5/3/18.
//  Copyright © 2018 Jada Mitchell. All rights reserved.
//

import Foundation
import UIKit
//this inherits from UITableViewController because otherwise we cant link it to the view in the storyboard
class ListTableViewController: UITableViewController{
    override func viewDidLoad(){
        super.viewDidLoad()
        //do any additonal setup after loading the view,typically from a nib
  
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
