//
//  ViewController.swift
//  InteriorDecorator
//
//  Created by Jada Mitchell on 4/16/18.
//  Copyright © 2018 Jada Mitchell. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var pickerView: UIView!
    @IBOutlet weak var label: UILabel!
    @IBAction func valueChanged(_ sender: Any) {
        let r = Int(red.value)
        let g = Int(green.value)
        let b = Int(blue.value)
        label.text = "RGB = (\(r),\(g),\(b))"
        view.backgroundColor = UIColor(red: CGFloat(red.value)/255.0,green:CGFloat(green.value)/255.0,blue:CGFloat(blue.value)/255.0,alpha:1.0)
        
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIDevice.current.orientation.isLandscape {
            pickerView.isHidden = true}
            else{
                pickerView.isHidden = false
            }
            
        
    }
    @IBOutlet weak var blue: UISlider!
    @IBOutlet weak var red: UISlider!
    @IBOutlet weak var green: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

